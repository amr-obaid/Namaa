<?php

use App\Http\Controllers\Api\SubscriberAuthController;
use App\Http\Controllers\Api\SubscriberController;
use App\Models\Acl;
use Illuminate\Contracts\Routing\Registrar as RouteContract;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::namespace('Api')->group(function () {
    Route::post('/upload', 'UploadController@upload');
    Route::post('auth/login', 'AuthController@login');
    Route::group(['middleware' => 'auth:sanctum'], function () {
        Route::post('auth/logout', 'AuthController@logout');

        Route::get('/user', 'AuthController@user');

        // Api resource routes
        Route::apiResource('roles', 'RoleController')->middleware('permission:' . Acl::PERMISSION_VIEW_MENU_PERMISSION);
        Route::apiResource('users', 'UserController')->middleware('permission:' . Acl::PERMISSION_VIEW_MENU_PERMISSION);
        Route::apiResource('permissions', 'PermissionController')->middleware('permission:' . Acl::PERMISSION_VIEW_MENU_PERMISSION);

        Route::apiResource('subscribers', 'SubscriberController')->middleware('permission:' . Acl::PERMISSION_VIEW_MENU_PERMISSION);

        Route::apiResource('blogs', 'BlogController')->middleware('permission:' . Acl::PERMISSION_VIEW_MENU_PERMISSION);
        Route::get('blogs/{blog}/status', 'BlogController@status')->middleware('permission:' . Acl::PERMISSION_VIEW_MENU_PERMISSION);


        Route::get('subscribers/{subscriber}/status', 'SubscriberController@status')->middleware('permission:' . Acl::PERMISSION_VIEW_MENU_PERMISSION);
        // Custom routes
        Route::group(['prefix' => 'users'], function (RouteContract $api) {
            $api->get('{user}/permissions', 'UserController@permissions')->middleware('permission:' . Acl::PERMISSION_VIEW_MENU_PERMISSION);
            $api->put('{user}/permissions', 'UserController@updatePermissions')->middleware('permission:' . Acl::PERMISSION_VIEW_MENU_PERMISSION);
            $api->get('{user}/logs', 'LogController@index');
        });

        Route::get('roles/{role}/permissions', 'RoleController@permissions')->middleware('permission:' . Acl::PERMISSION_VIEW_MENU_PERMISSION);
        Route::get('requests', 'RequestController@index');
    });
});
Route::group(['prefix' => 'subscriber'], function () {
    Route::post('/login', [SubscriberAuthController::class, 'login']);
    Route::group(['middleware' => 'auth:sanctum'], function () {
        Route::get('/user', [SubscriberAuthController::class, 'user']);
        Route::get('/blogs/list', [SubscriberController::class, 'blogs']);
        Route::post('/logout', [SubscriberAuthController::class, 'logout']);
    });
});
