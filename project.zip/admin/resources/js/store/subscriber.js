import { login, logout, getInfo } from '@/api/auth'
import { isLogged, setToken, removeToken } from '@/utils/subscriber'
import router, { resetRouter } from '../router'
import { defineStore } from 'pinia'

export const subscriberStore = defineStore('subscriber', {
  state: () => {
    return {
      id: null,
      user: null,
      token: null,
      name: '',
      username: ''
    }
  },
  actions: {
    // subscriber login
    login(userInfo) {
      const { username, password } = userInfo
      return new Promise((resolve, reject) => {
        login({ username: username, password: password })
          .then((response) => {
            setToken(response.data.token)
            resolve()
          })
          .catch((error) => {
            console.log(error)
            reject(error)
          })
      })
    },
    // get user info
    getInfo() {
      return new Promise((resolve, reject) => {
        getInfo()
          .then((response) => {
            const { data } = response

            if (!data) {
              reject('Verification failed, please Login again.')
            }

            const { name, username, id } = data

            this.$patch((state) => {
              state.id = id
              state.username = username
              state.name = name
            })
            resolve(data)
          })
          .catch((error) => {
            console.log(error)
            reject(error)
          })
      })
    },
    // user logout
    logout() {
      return new Promise((resolve, reject) => {
        logout()
          .then(() => {
            this.$patch((state) => {
              state.token = ''
            })
            removeToken()
            resetRouter()
            resolve()
          })
          .catch((error) => {
            reject(error)
          })
      })
    },
    // remove token
    resetToken() {
      return new Promise((resolve) => {
        this.$patch((state) => {
          state.token = ''
        })
        removeToken()
        resolve()
      })
    }
  }
})
