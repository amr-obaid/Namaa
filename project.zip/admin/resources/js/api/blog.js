import request from '@/utils/request'
import Resource from '@/api/resource'

class BlogResource extends Resource {
  constructor() {
    super('blogs')
  }
  changeStatus(id) {
    return request({
      url: '/' + this.uri + '/' + id + '/status',
      method: 'get'
    })
  }
}

export { BlogResource as default }
