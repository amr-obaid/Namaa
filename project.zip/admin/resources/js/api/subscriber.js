import request from '@/utils/request'
import Resource from '@/api/resource'

class SubscriberResource extends Resource {
  constructor() {
    super('subscribers')
  }
  changeStatus(id) {
    return request({
      url: '/' + this.uri + '/' + id + '/status',
      method: 'get'
    })
  }
}

export { SubscriberResource as default }
