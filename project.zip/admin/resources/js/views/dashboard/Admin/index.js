import component from './Admin.vue'
export default component
