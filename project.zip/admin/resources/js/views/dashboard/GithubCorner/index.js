import component from './GithubCorner.vue'
export default component
