<template>
  <div class="app-container">
    <el-card>
      <el-header>Subscriber Details</el-header>
      <el-form ref="refSubscriberUpdateForm" :model="subscriber" label-width="120px">
        <el-form-item :label="'Name'">
          <el-input v-model="subscriber.name" />
        </el-form-item>
        <el-form-item :label="'UserName'">
          <el-input v-model="subscriber.username" />
        </el-form-item>
        <el-form-item :label="'Password'" prop="password">
          <el-input v-model="subscriber.password" show-password />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="updateSubscriber(refSubscriberUpdateForm)">Save</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import SubscriberResource from '@/api/subscriber'
import { getCurrentInstance, onMounted, reactive, toRefs } from 'vue'
import { ElMessage } from 'element-plus'

const subscriberResource = new SubscriberResource('subscriber')
export default {
  name: 'EditUser',
  setup() {
    const refSubscriberUpdateForm = ref(null)
    const resData = reactive({
      subscriber: {}
    })
    const updateSubscriber = (formEl) => {
      if (!formEl) {
        return
      }
      formEl.validate((valid) => {
        if (valid) {
          resData.updating = true
          let params = {
            name: resData.subscriber.name,
            username: resData.subscriber.username,
            password: resData.subscriber.password
          }
          subscriberResource
            .update(resData.subscriber.id, params)
            .then((response) => {
              resData.updating = false
              ElMessage({
                message: 'Subscriber information has been updated successfully',
                type: 'success',
                duration: 5 * 1000
              })
            })
            .catch((error) => {
              console.log(error)
              resData.updating = false
            })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
    const { proxy } = getCurrentInstance()
    const getsubscriber = async (id) => {
      const { data } = await subscriberResource.get(id)
      resData.subscriber = data
    }
    onMounted(() => {
      const id = proxy.$route.params && proxy.$route.params.id

      getsubscriber(id)
    })

    return {
      ...toRefs(resData),
      refSubscriberUpdateForm,
      updateSubscriber
    }
  }
}
</script>
<style lang="scss" scoped>
.user-activity {
  .user-block {
    .username,
    .description {
      display: block;
      margin-left: 50px;
      padding: 2px 0;
    }

    img {
      width: 40px;
      height: 40px;
      float: left;
    }

    :after {
      clear: both;
    }

    .img-circle {
      border-radius: 50%;
      border: 2px solid #d2d6de;
      padding: 2px;
    }

    span {
      font-weight: 500;
      font-size: 12px;
    }
  }

  .post {
    font-size: 14px;
    border-bottom: 1px solid #d2d6de;
    margin-bottom: 15px;
    padding-bottom: 15px;
    color: #666;

    .image {
      width: 100%;
    }

    .user-images {
      padding-top: 20px;
    }
  }

  .list-inline {
    padding-left: 0;
    margin-left: -5px;
    list-style: none;

    li {
      display: inline-block;
      padding-right: 5px;
      padding-left: 5px;
      font-size: 13px;
    }

    .link-black {
      &:hover,
      &:focus {
        color: #999;
      }
    }
  }

  .el-carousel__item h3 {
    color: #475669;
    font-size: 14px;
    opacity: 0.75;
    line-height: 200px;
    margin: 0;
  }

  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }

  .el-carousel__item:nth-child(2n + 1) {
    background-color: #d3dce6;
  }
}
</style>

