<template>
  <div class="app-container scroll-y">
    <div class="filter-container">
      <el-input
        v-model="params.keyword"
        :placeholder="'Title'"
        style="width: 200px"
        class="filter-item"
        @keyup.enter.native="handleFilter"
      />

      <el-button class="filter-item" type="primary" :icon="Search" @click="handleFilter">
        {{ t('table.search') }}
      </el-button>
      <el-button class="filter-item" type="primary" :icon="Search" @click="handleSearch">Advanced Search</el-button>
      <el-button class="filter-item" type="primary" :icon="Plus" @click="handleCreate">
        {{ t('table.add') }}
      </el-button>
    </div>

    <custom-table
      :table-data="tableData"
      :table-column="basicColumn"
      :table-option="tableOption"
      :pagination="pagination"
      :paginate="true"
      :page-sizes="pageSizes"
      :loading="loading"
      @table-action="tableActions"
      @set-params="setParams"
    >
      <template #table_options="scope">
        <div>
          <el-button
            v-for="(action, index) in tableOption.item_actions"
            :type="action.type ? action.type : 'primary'"
            :size="action.size ? action.size : ''"
            @click="tableActions(action.name, scope.row)"
          >
            <el-svg-item :el-svg-name="action.icon" :title="action.label"></el-svg-item>
          </el-button>
        </div>
      </template>
    </custom-table>
    <el-dialog :title="'Advanced Search'" v-model="dialogSearchVisible">
      <div v-loading="blogCreating" class="form-container">
        <el-form
          ref="refSearchBlogForm"
          :rules="rules"
          :model="newBlog"
          label-position="left"
          label-width="150px"
          style="max-width: 500px"
        >
          <el-form-item :label="'Title'" prop="searchTitle">
            <el-input v-model="params.searchName" />
          </el-form-item>
          <el-form-item :label="'Publish Date'" prop="searchPublishdate">
            <el-date-picker
              v-model="params.searchPublishdate"
              type="date"
              :placeholder="'Publish Date'"
              value-format="YYYY-MM-DD"
            />
          </el-form-item>
          <el-form-item :label="'Status'" prop="searchStatus">
            <el-select
              v-model="params.searchStatus"
              :placeholder="'Status'"
              prop="searchStatus"
              clearable
              class="filter-item"
            >
              <el-option :label="uppercaseFirst('Active')" value="true" />
              <el-option :label="uppercaseFirst('UnActive')" value="false" />
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogSearchVisible = false">
            {{ t('table.cancel') }}
          </el-button>
          <el-button type="primary" @click="handleSearchFilter">
            {{ t('table.confirm') }}
          </el-button>
        </div>
      </div>
    </el-dialog>

    <el-dialog :title="'Create new Blog'" v-model="dialogFormVisible">
      <div v-loading="blogCreating" class="form-container">
        <el-form
          ref="refBlogForm"
          :rules="rules"
          :model="newBlog"
          label-position="left"
          label-width="150px"
          style="max-width: 500px"
        >
          <el-form-item :label="'Title'" prop="title">
            <el-input v-model="newBlog.title" />
          </el-form-item>
          <el-form-item :label="'Image'" prop="image">
            <el-upload
              class="avatar-uploader"
              action="/api/upload"
              :show-file-list="false"
              :on-success="handleAvatarSuccess"
              :before-upload="beforeAvatarUpload"
            >
              <img v-if="newBlog.image" :src="newBlog.image" class="avatar" />
              <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
            </el-upload>
          </el-form-item>
          <el-form-item :label="'Content'" prop="content">
            <el-input v-model="newBlog.content" :rows="6" type="textarea" placeholder="Please Enter Your Content" />
          </el-form-item>
          <el-form-item :label="'Publish Date'" prop="publish_date">
            <el-date-picker
              v-model="newBlog.publish_date"
              type="date"
              :placeholder="'Publish Date'"
              value-format="YYYY-MM-DD"
            />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">
            {{ t('table.cancel') }}
          </el-button>
          <el-button type="primary" @click="createBlog(refBlogForm)">
            {{ t('table.confirm') }}
          </el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import CustomTable from '@/components/CustomTable.vue'
import ElSvgItem from '@/components/Item/ElSvgItem.vue'
import BlogResource from '@/api/blog'
import Resource from '@/api/resource'
import { ElMessage, ElMessageBox } from 'element-plus'
import { uppercaseFirst } from '../../utils'
import { useI18n } from 'vue-i18n'
import { Search, Plus } from '@element-plus/icons-vue'
import dayjs from 'dayjs'
export default {
  components: { CustomTable, ElSvgItem },
  setup() {
    const { t } = useI18n({ useScope: 'global' })
    const blogResource = new BlogResource()
    const refBlogForm = ref(null)
    const refSearchBlogForm = ref(null)

    const handleAvatarSuccess = (response, uploadFile) => {
      resData.newBlog.image = response.url
    }

    const beforeAvatarUpload = (rawFile) => {
      if (rawFile.type !== 'image/jpeg') {
        ElMessage.error('Avatar picture must be JPG format!')
        return false
      } else if (rawFile.size / 1024 / 1024 > 2) {
        ElMessage.error('Avatar picture size can not exceed 2MB!')
        return false
      }
      return true
    }

    const resData = reactive({
      basicColumn: [
        {
          prop: 'id',
          label: 'ID',
          width: '100'
        },
        {
          prop: 'title',
          label: 'Title',
          width: '200'
        },
        {
          prop: 'image',
          label: 'Image'
        },
        {
          prop: 'publish_date',
          label: 'Publish Date',
          width: '200'
        },
        {
          prop: 'status',
          label: 'Status',
          width: '200'
        }
      ],
      tableOption: {},
      tableData: [],
      loading: true,
      pagination: {
        total: 0,
        currentPage: 1,
        pageSize: 10
      },
      params: {
        page: 1,
        per_page: 10,
        keyword: ''
      },
      pageSizes: [10, 30, 50, 100],
      dialogFormVisible: ref(false),
      dialogSearchVisible: ref(false),
      blogCreating: false,
      newBlog: {},
      rules: {
        title: [{ required: true, message: 'Title is required', trigger: 'blur' }],
        content: [{ required: true, message: 'Content is required', trigger: 'blur' }],
        image: [{ required: true, message: 'Image is required', trigger: 'blur' }],
        publish_date: [{ required: true, message: 'Publish Date is required', trigger: 'blur' }]
      },
      currentUserId: 0,
      currentUser: {
        name: ''
      }
    })

    resData.tableOption = {
      slot: true,
      label: t('table.actions'),
      fixed: 'right',
      item_actions: [
        { name: 'edit-item', type: 'primary', icon: 'EditPen', label: t('table.edit') },
        { name: 'change-status', type: 'warning', icon: 'EditPen', label: 'Change Status' },
        { name: 'delete-item', type: 'danger', icon: 'Delete', label: t('table.delete') }
      ]
    }

    const getList = () => {
      resData.loading = true
      blogResource.list(resData.params).then((res) => {
        resData.tableData = res.data
        resData.pagination = res.meta
        resData.loading = false
      })
    }

    const handleFilter = () => {
      resData.params.page = 1
      getList()
      if (refBlogForm) {
        refBlogForm.clearValidate()
      }
    }

    const handleSearchFilter = () => {
      resData.params.page = 1
      getList()
      resData.dialogSearchVisible = false
    }

    const setParams = (key, value) => {
      if (key !== 'per_page' && key !== 'page') {
        resData.params.page = 1
      }
      resData.params[key] = value
      getList()
    }
    const router = useRouter()
    const tableActions = (action, data) => {
      if (action === 'edit-item') {
        router.push(`/blog/edit/${data.id}`)
      } else if (action == 'change-status') {
        ElMessageBox.confirm('This will change the Blog ' + data.name + ' Status. Continue?', 'Warning', {
          confirmButtonText: 'OK',
          cancelButtonText: 'Cancel',
          type: 'warning'
        })
          .then(() => {
            blogResource
              .changeStatus(data.id)
              .then((response) => {
                ElMessage({
                  type: 'success',
                  message: 'Changed Successfully'
                })
                handleFilter()
              })
              .catch((error) => {
                console.log(error)
              })
          })
          .catch(() => {
            ElMessage({
              type: 'info',
              message: 'Delete canceled'
            })
          })
      } else if (action === 'delete-item') {
        ElMessageBox.confirm('This will permanently delete Blog ' + data.name + '. Continue?', 'Warning', {
          confirmButtonText: 'OK',
          cancelButtonText: 'Cancel',
          type: 'warning'
        })
          .then(() => {
            blogResource
              .destroy(data.id)
              .then((response) => {
                ElMessage({
                  type: 'success',
                  message: 'Delete completed'
                })
                handleFilter()
              })
              .catch((error) => {
                console.log(error)
              })
          })
          .catch(() => {
            ElMessage({
              type: 'info',
              message: 'Delete canceled'
            })
          })
      }
    }

    const handleCreate = () => {
      resetNewBlog()
      resData.dialogFormVisible = true
    }

    const handleSearch = () => {
      resData.dialogSearchVisible = true
    }
    const createBlog = (formEl) => {
      if (!formEl) {
        return
      }
      formEl.validate((valid) => {
        if (valid) {
          if (resData.newBlog.publish_date) {
            resData.newBlog.publish_date = dayjs(resData.newBlog.publish_date).format('YYYY-MM-DD')
          }
          resData.blogCreating = true
          blogResource
            .store(resData.newBlog)
            .then((response) => {
              ElMessage({
                message: 'New Blog ' + resData.newBlog.title + 'has been created successfully.',
                type: 'success',
                duration: 5 * 1000
              })
              resetNewBlog()
              resData.dialogFormVisible = false
              handleFilter()
            })
            .catch((error) => {
              console.log(error)
            })
            .finally(() => {
              resData.blogCreating = false
            })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
    const resetNewBlog = () => {
      resData.newBlog = {}
    }

    onMounted(() => {
      getList()
    })

    return {
      t,
      refBlogForm,
      refSearchBlogForm,
      ...toRefs(resData),
      getList,
      handleFilter,
      handleSearchFilter,
      setParams,
      tableActions,
      uppercaseFirst,
      handleCreate,
      handleSearch,
      createBlog,
      handleAvatarSuccess,
      beforeAvatarUpload,
      Search,
      Plus
    }
  }
}
</script>

<style lang="scss" scoped>
.edit-input {
  padding-right: 100px;
}

.cancel-btn {
  position: absolute;
  right: 15px;
  top: 10px;
}

.dialog-footer {
  text-align: left;
  padding-top: 0;
  margin-left: 150px;
}

.app-container {
  flex: 1;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;

  .block {
    float: left;
    min-width: 250px;
  }

  .clear-left {
    clear: left;
  }
}
</style>
<style scoped>
.avatar-uploader .avatar {
  width: 178px;
  height: 178px;
  display: block;
}
</style>

<style>
.avatar-uploader .el-upload {
  border: 1px dashed var(--el-border-color);
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: var(--el-transition-duration-fast);
}

.avatar-uploader .el-upload:hover {
  border-color: var(--el-color-primary);
}

.el-icon.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  text-align: center;
}
</style>
