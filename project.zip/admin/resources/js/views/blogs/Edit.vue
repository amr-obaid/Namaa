<template>
  <div class="app-container">
    <el-card>
      <el-header>Blog Details</el-header>
      <el-form ref="refBlogUpdateForm" :model="blog" label-width="120px">
        <el-form-item :label="'Title'" prop="title">
          <el-input v-model="blog.title" />
        </el-form-item>
        <el-form-item :label="'Image'" prop="image">
          <el-upload
            class="avatar-uploader"
            action="/api/upload"
            :show-file-list="false"
            :on-success="handleAvatarSuccess"
            :before-upload="beforeAvatarUpload"
          >
            <img v-if="blog.image" :src="blog.image" class="avatar" />
            <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
          </el-upload>
        </el-form-item>
        <el-form-item :label="'Content'" prop="content">
          <el-input v-model="blog.content" :rows="6" type="textarea" placeholder="Please Enter Your Content" />
        </el-form-item>
        <el-form-item :label="'Publish Date'" prop="publish_date">
          <el-date-picker
            v-model="blog.publish_date"
            type="date"
            :placeholder="'Publish Date'"
            value-format="YYYY-MM-DD"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="updateBlog(refBlogUpdateForm)">Save</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import BlogResource from '@/api/blog'
import { getCurrentInstance, onMounted, reactive, toRefs } from 'vue'
import { ElMessage } from 'element-plus'

const blogResource = new BlogResource('blog')
export default {
  name: 'EditUser',
  setup() {
    const handleAvatarSuccess = (response, uploadFile) => {
      resData.blog.image = response.url
    }

    const beforeAvatarUpload = (rawFile) => {
      if (rawFile.type !== 'image/jpeg') {
        ElMessage.error('Avatar picture must be JPG format!')
        return false
      } else if (rawFile.size / 1024 / 1024 > 2) {
        ElMessage.error('Avatar picture size can not exceed 2MB!')
        return false
      }
      return true
    }
    const refBlogUpdateForm = ref(null)
    const resData = reactive({
      blog: {}
    })
    const updateBlog = (formEl) => {
      if (!formEl) {
        return
      }
      formEl.validate((valid) => {
        if (valid) {
          resData.updating = true
          let params = {
            title: resData.blog.title,
            image: resData.blog.image,
            content: resData.blog.content,
            publish_date: resData.blog.publish_date
          }
          blogResource
            .update(resData.blog.id, params)
            .then((response) => {
              resData.updating = false
              ElMessage({
                message: 'Blog information has been updated successfully',
                type: 'success',
                duration: 5 * 1000
              })
            })
            .catch((error) => {
              console.log(error)
              resData.updating = false
            })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
    const { proxy } = getCurrentInstance()
    const getblog = async (id) => {
      const { data } = await blogResource.get(id)
      resData.blog = data
    }
    onMounted(() => {
      const id = proxy.$route.params && proxy.$route.params.id

      getblog(id)
    })

    return {
      ...toRefs(resData),
      refBlogUpdateForm,
      handleAvatarSuccess,
      beforeAvatarUpload,
      updateBlog
    }
  }
}
</script>
<style lang="scss" scoped>
.user-activity {
  .user-block {
    .username,
    .description {
      display: block;
      margin-left: 50px;
      padding: 2px 0;
    }

    img {
      width: 40px;
      height: 40px;
      float: left;
    }

    :after {
      clear: both;
    }

    .img-circle {
      border-radius: 50%;
      border: 2px solid #d2d6de;
      padding: 2px;
    }

    span {
      font-weight: 500;
      font-size: 12px;
    }
  }

  .post {
    font-size: 14px;
    border-bottom: 1px solid #d2d6de;
    margin-bottom: 15px;
    padding-bottom: 15px;
    color: #666;

    .image {
      width: 100%;
    }

    .user-images {
      padding-top: 20px;
    }
  }

  .list-inline {
    padding-left: 0;
    margin-left: -5px;
    list-style: none;

    li {
      display: inline-block;
      padding-right: 5px;
      padding-left: 5px;
      font-size: 13px;
    }

    .link-black {
      &:hover,
      &:focus {
        color: #999;
      }
    }
  }

  .el-carousel__item h3 {
    color: #475669;
    font-size: 14px;
    opacity: 0.75;
    line-height: 200px;
    margin: 0;
  }

  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }

  .el-carousel__item:nth-child(2n + 1) {
    background-color: #d3dce6;
  }
}
</style>

