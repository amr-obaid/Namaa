/** When your routing table is too long, you can split it into small modules**/
import Layout from '@/layout/Layout.vue'

const SubscriberRoutes = {
  path: '/subscriber',
  component: Layout,
  redirect: 'noRedirect',
  name: 'Subscriber',
  meta: {
    title: 'subscribers',
    bootstrapIcon: 'users',
    permissions: []
  },
  children: [
    {
      path: 'list',
      component: () => import('@/views/subscribers/List.vue'),
      name: 'Subscribers List',
      meta: { title: 'Subscribers', bootstrapIcon: 'person-lines-fill', noCache: true }
    },
    {
      path: 'edit/:id(\\d+)',
      component: () => import('@/views/subscribers/Edit.vue'),
      name: 'Subscriber Edit',
      meta: { title: 'Edit Subscriber', noCache: true },
      hidden: true
    }
  ]
}
export default SubscriberRoutes
