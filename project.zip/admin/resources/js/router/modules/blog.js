/** When your routing table is too long, you can split it into small modules**/
import Layout from '@/layout/Layout.vue'

const BlogRoutes = {
  path: '/blog',
  component: Layout,
  redirect: 'noRedirect',
  name: 'Blog',
  meta: {
    title: 'Blogs',
    permissions: []
  },
  children: [
    {
      path: 'list',
      component: () => import('@/views/blogs/List.vue'),
      name: 'Blogs List',
      meta: { title: 'blogs', bootstrapIcon: 'image', noCache: true }
    },
    {
      path: 'edit/:id(\\d+)',
      component: () => import('@/views/blogs/Edit.vue'),
      name: 'Blog Edit',
      meta: { title: 'Edit Blog', noCache: true },
      hidden: true
    }
  ]
}

export default BlogRoutes
