<?php

namespace App\Http\Controllers\Api;

use App\Http\Resources\PermissionResource;
use App\Http\Resources\BlogResource;
use App\Models\Acl;
use App\Models\Log;
use App\Models\Permission;
use App\Models\Role;
use App\Models\Blog;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

/**
 * Class BlogController
 *
 * @package App\Http\Controllers\Api
 */
class BlogController extends BaseController
{
    /**
     * Display a listing of the blog resource.
     *
     * @param Request $request
     * @return AnonymousResourceCollection
     */
    public function index(Request $request)
    {
        $params = $request->all();

        $data = Blog::query()
            ->when(!empty($params['keyword']), function (Builder $query) use ($params) {
                $query->where(function ($q) use ($params) {
                    $q->where('title', 'like', '%' . $params['keyword'] . '%');
                });
            })->when(!empty($params['searchTitle']), function (Builder $query) use ($params) {
                $query->where(function ($q) use ($params) {
                    $q->where('title', 'like', '%' . $params['searchTitle'] . '%');
                });
            })->when(!empty($params['searchStatus']), function (Builder $query) use ($params) {
                $query->where(function ($q) use ($params) {
                    $q->where('status', $params['searchStatus']);
                });
            })->when(!empty($params['searchPublishdate']), function (Builder $query) use ($params) {
                $query->where(function ($q) use ($params) {
                    $q->where('publish_date',  $params['searchPublishdate']);
                });
            })
            ->paginate($params['per_page'] ?? 10);

        return BlogResource::collection($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     */
    public function store(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            $this->getValidationRules(),
        );

        if ($validator->fails()) {
            return responseFailed($validator->errors()->first(), Response::HTTP_BAD_REQUEST);
        } else {
            try {
                $params = $request->all();
                DB::beginTransaction();
                $blog = Blog::create([
                    'title' => $params['title'],
                    'content' => $params['content'],
                    'image' => $params['image'],
                    'publish_date' => $params['publish_date'],
                ]);

                DB::commit();

                return new BlogResource($blog);
            } catch (\Exception $ex) {
                DB::rollBack();
                return responseFailed($ex->getMessage());
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param Blog $blog
     * @return BlogResource|\Illuminate\Http\JsonResponse
     */
    public function show(Blog $blog)
    {
        return new BlogResource($blog);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Blog $blog
     * @return BlogResource|\Illuminate\Http\JsonResponse
     */
    public function update(Request $request, Blog $blog)
    {
        if ($blog === null) {
            return response()->json(['error' => 'Blog not found'], Response::HTTP_NOT_FOUND);
        }
        $validator = Validator::make($request->all(), $this->getValidationRules(false));
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 403);
        }

        $blog->image = $request->image;
        $blog->title = $request->title;
        $blog->content = $request->content;
        $blog->publish_date = $request->publish_date;
        $blog->save();
        return new BlogResource($blog);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Blog $blog
     * @return BlogResource|\Illuminate\Http\JsonResponse
     */
    public function status(Request $request, Blog $blog)
    {
        if ($blog === null) {
            return response()->json(['error' => 'Blog not found'], Response::HTTP_NOT_FOUND);
        }
        $blog->status = !$blog->status;
        $blog->save();
        return new BlogResource($blog);
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param Blog $blog
     */
    public function destroy(Blog $blog)
    {
        try {
            $blog->delete();
        } catch (\Exception $ex) {
            return responseFailed($ex->getMessage(), Response::HTTP_FORBIDDEN);
        }

        return responseSuccess();
    }


    /**
     * @param bool $isNew
     * @return array
     */
    private function getValidationRules(bool $isNew = true): array
    {
        return [
            'title' => $isNew ? 'required' : '',
            'content' => $isNew ? 'required' : '',
            'image' => $isNew ? 'required' : '',
            'publish_date' => $isNew ? 'required' : '',
        ];
    }
}
