<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ProductImage;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class UploadController extends Controller
{


    public function upload(Request $request)
    {
        $file = $request->file('file')->getFilename();
        $name = pathinfo($file, PATHINFO_FILENAME);
        $random = Str::random(16);
        $fileName = $name . '_' . $random . '.' . $request->file('file')->extension();
        $path = 'images/' . $fileName;
        if (!file_exists($path)) {
            $request->file('file')->move(public_path('images'), $fileName);
        }
        return response()->json(['url' => "/$path"]);
    }

    public function remove(Request $request)
    {
    }
}
