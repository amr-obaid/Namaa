<?php

namespace App\Http\Controllers\Api;

use App\Http\Resources\BlogResource;
use App\Http\Resources\SubscriberResource;
use App\Http\Resources\UserResource;
use App\Models\Blog;
use App\Models\Subscriber;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

/**
 * Class AuthController
 *
 * @package App\Http\Controllers\Api
 */
class SubscriberAuthController extends BaseController
{
    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function login(Request $request)
    {
        $data = $request->validate([
            'username' => 'required',
            'password' => 'required'
        ]);
        $user = Subscriber::query()->where('username', $request->input('username'))->first();
        if (empty($user) || !Hash::check($request->input('password'), $user->password)) {
            return responseFailed('These credentials do not match our records.', Response::HTTP_UNAUTHORIZED);
        }
        if (count($user->tokens) > 0) {
            return responseFailed('This Account Already Logged in from another device', Response::HTTP_FORBIDDEN);
        }
        $user->token = $user->createToken($user->username)->plainTextToken;

        return responseSuccess($user);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function logout(Request $request): JsonResponse
    {
        $request->user()->tokens()->delete();
        Auth::guard('web')->logout();

        return responseSuccess();
    }

    public function user(Request $request): SubscriberResource
    {
        return new SubscriberResource($request->user());
    }
}
