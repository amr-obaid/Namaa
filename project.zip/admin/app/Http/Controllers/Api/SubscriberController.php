<?php

namespace App\Http\Controllers\Api;

use App\Http\Resources\BlogResource;
use App\Http\Resources\PermissionResource;
use App\Http\Resources\SubscriberResource;
use App\Models\Acl;
use App\Models\Blog;
use App\Models\Log;
use App\Models\Permission;
use App\Models\Role;
use App\Models\Subscriber;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

/**
 * Class SubscriberController
 *
 * @package App\Http\Controllers\Api
 */
class SubscriberController extends BaseController
{
    /**
     * Display a listing of the subscriber resource.
     *
     * @param Request $request
     * @return AnonymousResourceCollection
     */
    public function index(Request $request)
    {
        $params = $request->all();

        $data = Subscriber::query()
            ->when(!empty($params['keyword']), function (Builder $query) use ($params) {
                $query->where(function ($q) use ($params) {
                    $q->where('name', 'like', '%' . $params['keyword'] . '%');
                });
            })->when(!empty($params['searchName']), function (Builder $query) use ($params) {
                $query->where(function ($q) use ($params) {
                    $q->where('name', 'like', '%' . $params['searchName'] . '%');
                });
            })->when(!empty($params['searchStatus']), function (Builder $query) use ($params) {
                $query->where(function ($q) use ($params) {
                    $q->where('status', $params['searchStatus']);
                });
            })->when(!empty($params['searchUsername']), function (Builder $query) use ($params) {
                $query->where(function ($q) use ($params) {
                    $q->where('username', 'like', '%' . $params['searchUsername'] . '%');
                });
            })
            ->paginate($params['per_page'] ?? 10);

        return SubscriberResource::collection($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     */
    public function store(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            array_merge(
                $this->getValidationRules(),
                [
                    'password' => ['required', 'min:6'],
                    'confirmPassword' => 'same:password',
                ]
            )
        );

        if ($validator->fails()) {
            return responseFailed($validator->errors()->first(), Response::HTTP_BAD_REQUEST);
        } else {
            try {
                $params = $request->all();
                DB::beginTransaction();
                $subscriber = Subscriber::create([
                    'name' => $params['name'],
                    'username' => $params['username'],
                    'password' => Hash::make($params['password']),
                ]);

                DB::commit();

                return new SubscriberResource($subscriber);
            } catch (\Exception $ex) {
                DB::rollBack();
                return responseFailed($ex->getMessage());
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param Subscriber $subscriber
     * @return SubscriberResource|\Illuminate\Http\JsonResponse
     */
    public function show(Subscriber $subscriber)
    {
        return new SubscriberResource($subscriber);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Subscriber $subscriber
     * @return SubscriberResource|\Illuminate\Http\JsonResponse
     */
    public function update(Request $request, Subscriber $subscriber)
    {
        if ($subscriber === null) {
            return response()->json(['error' => 'Subscriber not found'], Response::HTTP_NOT_FOUND);
        }
        $validator = Validator::make($request->all(), $this->getValidationRules(false));
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 403);
        }
        $subscriber->name = $request->name;
        $subscriber->username = $request->username;
        if (isset($request['password'])) {
            if ($request['password'] != '')
                $subscriber->password = Hash::make($request['password']);
        }
        $subscriber->save();
        return new SubscriberResource($subscriber);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Subscriber $subscriber
     * @return SubscriberResource|\Illuminate\Http\JsonResponse
     */
    public function status(Request $request, Subscriber $subscriber)
    {
        if ($subscriber === null) {
            return response()->json(['error' => 'Subscriber not found'], Response::HTTP_NOT_FOUND);
        }
        $subscriber->status = !$subscriber->status;
        $subscriber->save();
        return new SubscriberResource($subscriber);
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param Subscriber $subscriber
     */
    public function destroy(Subscriber $subscriber)
    {
        try {
            $subscriber->delete();
        } catch (\Exception $ex) {
            return responseFailed($ex->getMessage(), Response::HTTP_FORBIDDEN);
        }

        return responseSuccess();
    }


    /**
     * @param bool $isNew
     * @return array
     */
    private function getValidationRules(bool $isNew = true): array
    {
        return [
            'name' => $isNew ? 'required' : '',
            'username' => $isNew ? 'required|unique:subscribers' : '',
        ];
    }

    public function blogs(Request $request)
    {
        try {
            $blogs = Blog::where('status', true)->get();
            return responseSuccess(BlogResource::collection($blogs));
        } catch (\Exception $ex) {
            return responseFailed($ex->getMessage(), Response::HTTP_FORBIDDEN);
        }
    }
}
