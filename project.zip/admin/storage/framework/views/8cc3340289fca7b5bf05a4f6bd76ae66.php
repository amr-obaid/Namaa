<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Namma Solutions</title>
    <link rel="shortcut icon" href="https://namaa-solutions.com/frontend/images/logo_en.png">
    <meta name="theme-color" content="#ffffff">
</head>

<body>
    <div id="app">
    </div>

    <?php echo e(vite_assets()); ?>


    <?php if(config('content.google.open')): ?>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e(config('content.google.id')); ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }

            gtag('js', new Date());

            gtag('config', '<?php echo e(config('content.google.id')); ?>');
        </script>
    <?php endif; ?>
</body>

</html>
<?php /**PATH C:\work\namaa\try2\laravel-vue-admin\resources\views/index.blade.php ENDPATH**/ ?>