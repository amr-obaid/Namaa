import axios from "axios";
import VueAxios from "vue-axios";
import { createApp } from "vue";
import router from "./router";
import Loading from "vue-loading-overlay";
import "vue-loading-overlay/dist/vue-loading.css";
import "./assets/main.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap";
import { FontAwesomeIcon } from "@fortawesome/vue-fontawesome";

import store from "./store";
import App from "./App.vue";
const app = createApp(App);
import { library } from "@fortawesome/fontawesome-svg-core";
import {
  faEyeSlash,
  faEye,
  faPlusCircle,
} from "@fortawesome/free-solid-svg-icons";
library.add(faEyeSlash);
library.add(faEye);
library.add(faPlusCircle);
store.commit("auth/initializeStoreFromLocalStorage");
app.component("loading", Loading);
app.component("font-awesome-icon", FontAwesomeIcon);
app.use(VueAxios, axios);
app.use(store);
app.use(router);
app.mount("#app");
