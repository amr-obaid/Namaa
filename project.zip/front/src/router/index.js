import { createRouter, createWebHistory } from "vue-router";
import store from "../store/";

/* Layouts */
const Layout = () =>
  import(
    "../Layout/Home.vue" /* webpackChunkName: "resource/js/components/layouts/home" */
  );

/* Pages */
const Home = () => import("../views/Home.vue");
const Login = () => import("../views/Login.vue");

const routes = [
  {
    path: "/login",
    component: Layout,
    meta: {
      middleware: "guest",
    },
    children: [
      {
        name: "login",
        path: "/login",
        component: Login,
        meta: {
          middleware: "guest",
          title: `Login`,
        },
      },
    ],
  },
  {
    path: "/",
    component: Layout,
    meta: {
      middleware: "auth",
    },
    children: [
      {
        name: "home",
        path: "/",
        component: Home,
        meta: {
          title: `Home`,
        },
      },
    ],
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach((to, from, next) => {
  document.title = `Namaa - ${to.meta.title} `;
  if (to.meta.middleware == "guest") {
    next();
  } else {
    const isAuthenticated = store.state["auth"].authenticated;
    if (isAuthenticated) {
      next();
    } else {
      next({ name: "login" });
    }
  }
});

export default router;
