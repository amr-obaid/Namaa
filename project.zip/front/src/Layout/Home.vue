<template>
  <section dir="ltr">
    <nav
      class="navbar navbar-expand-lg navbar-light bg-light mynavbar sticky-top"
    >
      <div class="container-fluid">
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarTogglerDemo03"
          aria-controls="navbarTogglerDemo03"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand logo" href="/"
          ><img
            src="https://namaa-solutions.com/frontend/images/logo_en.png"
            width="120"
        /></a>
        <div
          class="collapse navbar-collapse justify-content-center"
          id="navbarTogglerDemo03"
        >
          <ul class="navbar-nav m-auto"></ul>
          <a
            class="login-btn cme-auto nav-item"
            v-if="isAuthenticated"
            @click="logout"
          >
            Logout</a
          >
        </div>
      </div>
    </nav>
    <main class="main-page">
      <router-view v-slot="{ Component }">
        <component ref="view" :is="Component" />
      </router-view>
    </main>
  </section>
</template>
    
<script>
import { mapGetters, mapActions } from "vuex";
import axios from "axios";
export default {
  name: "home-layout",

  setup() {},
  computed: {
    ...mapGetters("auth", ["isAuthenticated", "token"]),
  },
  methods: {
    ...mapActions(["logoutUser"]),
    logout() {
      console.log(this.isAuthenticated);
      try {
        console.log("Hi2");
        axios
          .post(
            "http://127.0.0.1:8000/api/subscriber/logout",
            {},
            {
              headers: {
                Authorization: "Bearer " + this.token,
              },
            }
          )
          .then((response) => {
            if (!response.data.success) {
              this.error = response.data.message;
            }
            this.logoutUser();
            this.$router.push({ name: "login" });
            this.isLoading = false;
          })
          .catch((error) => {
            console.log(error);
            this.error = error.response.data.message;
            this.isLoading = false;
          });
      } catch (error) {
        console.log(error);
        this.error = error.message;
        this.isLoading = false;
      }
    },
    changeLoading() {
      this.isLoading = !this.isLoading;
    },
  },
  mounted() {},
};
</script>

<style>
.nav-link {
  font-family: "Poppins", sans-serif;
}
.main-page {
  margin-top: 6%;
}
.cme-4 {
  margin-right: 1.5rem !important;
}
.cme-auto {
  margin-right: auto !important;
}

.logo {
  margin-left: 10%;
}
.page-title {
  border-left: solid 3px #000;
}
.page-subtitle {
  border-left: solid 3px #ffffff;
}

.add-right {
  text-align: right;
}
.radio-img {
  float: right;
}
.page-title {
  font-style: normal;
  font-weight: 700;
  line-height: 120%;
  margin: 4%;
  padding-right: 2%;
  padding-left: 2%;
}
.add-right {
  padding-bottom: 2%;
  font-style: normal;
  font-weight: 400;
  letter-spacing: -0.02em;
  text-transform: capitalize;
}
.add-left {
  font-style: normal;
  font-weight: 500;
  text-transform: capitalize;
}
.foot-dark {
  background-color: rgb(28, 45, 47) !important;
  text-align: left;
  border: none;
  width: 100%;
}
.dark {
  background-color: rgb(28, 45, 47) !important;
  text-align: left;
  border: none;
  width: 80%;
}
.carousel__slide {
  color: white;
}
.carousel__prev,
.carousel__next {
  background-color: var(--vc-nav-background-color);
  background-color: rgb(28, 45, 47) !important;
}
input:-webkit-autofill,
input:-webkit-autofill:hover,
input:-webkit-autofill:focus,
input:-webkit-autofill:active {
  -webkit-box-shadow: 0 0 0 30px white inset !important;
}
body {
  overflow-x: hidden;
  background-color: #f5feff;
  color: #000;
  display: block;
  text-decoration: none;
}
.add-shadow {
  box-shadow: -2px 1px 12px 2px rgba(0, 0, 0, 0.25);
}
.mynavbar {
  background: #ffffff;
  /* box-shadow: -2px 1px 12px 2px rgba(0, 0, 0, 0.25); */
  border-radius: 0px 0px 10px 10px;
  opacity: 0.8;
  width: 90%;
  margin: auto;
}
.login-btn {
  border: 1px solid #beced0;
  border-radius: 10px;
  font-family: "Poppins";
  font-style: normal;
  font-weight: 400;
  font-size: 120%;
  line-height: 120%;
  width: 8%;
  text-decoration: none;
  text-align: center;
  text-transform: capitalize;
  padding: 0.4%;

  color: #e8b980;
}
.navbar-expand-lg {
  display: flex !important;
  justify-content: space-around;
  flex-basis: auto;
}
.navbar-collapse .nav-item {
}
.nav-item {
  font-family: "Poppins";
  font-style: normal;
  font-weight: 400;
  font-size: 18px;
  line-height: 120%;
  /* identical to box height, or 22px */

  color: #e8b980;
  z-index: 999999;
}
/* .navbar-nav {
  display: flex;
  flex-direction: row;
  padding-left: 0;
  margin-bottom: 0;
  max-width: none;
  list-style: none;
  justify-content: center;
  flex-wrap: nowrap;
  align-content: center;
  align-items: center;
} */
.navbar-light .navbar-nav .nav-link {
  color: #e8b980;
}
.form-box {
  box-sizing: border-box;
  width: 33%;
  margin: auto;
  padding: 2%;

  background: #ffffff;
  mix-blend-mode: normal;
  /* sh */

  box-shadow: -1px 30px 31px -14px rgba(0, 0, 0, 0.25);
  border-radius: 30px;
}
.form-box2 {
  box-sizing: border-box;
  width: 66%;
  margin: auto;
  padding: 2%;

  background: #ffffff;
  mix-blend-mode: normal;
  /* sh */

  box-shadow: -1px 30px 31px -14px rgba(0, 0, 0, 0.25);
  border-radius: 30px;
}
.form-field {
  background: #ffffff;
  border: 1.5px solid #e8b980;
  border-radius: 15px;
  width: 96%;
  padding-left: 4%;
  padding-right: 4%;
  margin: 2%;
  height: 3rem;
}
.contact-form-field {
  background: #ffffff;
  border-radius: 15px;
  width: 100%;
  margin-top: 4%;
  height: 3rem;
  padding-left: 4%;
  padding-right: 4%;
  border: 0.5px solid #e8b980;
}
.form-button {
  border: solid 1px #2fa9b8;
  background: #2fa9b8;
  border-radius: 15px;
  width: 96% !important;
  margin: 2%;
  height: 2.8rem;
  font-style: normal;
  font-weight: 700;
  color: #ffffff;
}
.danger {
  color: red;
  line-height: 50%;
}
.password-icon {
  position: absolute;
  top: 38%;
}
.password-icon {
  right: 8%;
}
.dark-div {
  background-color: #e8b980;
  padding: 4%;
  padding-left: 6%;
  padding-right: 6%;
}
.dark-div-text {
  width: 65%;
  font-style: normal;
  font-weight: 400;
  line-height: 120%;
  text-align: center;
  color: #ffffff;
}
.phone-img {
  width: 70%;
  margin-top: 12%;
  margin-left: 8%;
  margin-right: 8%;
}
.phone-text {
  margin-top: 20%;
  font-style: normal;
  font-weight: 400;
  width: 65%;
  margin-left: 17%;
  margin-right: 18%;
  color: #ffffff;
}
.light-div {
  background-color: #f5feff;
  padding-top: 4%;
  padding-bottom: 5%;
  padding-left: 6%;
  padding-right: 6%;
}
.contact-form {
  padding: 6%;
  padding-bottom: 2%;
  background: #ffffff;
  border: 1px solid #e8b980;
  border-radius: 30px;
}
.social-button {
  color: #fff;
  margin: 2%;
  z-index: 100;
  width: 10%;
}
a:hover {
  cursor: pointer;
  background-color: transparent;
}

input:focus ~ .floating-label {
  display: inline-block;
}
textarea:focus ~ .floating-label {
  display: inline-block;
}

select:focus ~ .floating-label {
  display: inline-block;
}

.floating-label {
  position: absolute;
  pointer-events: none;
  top: 0%;
  font-size: 80%;
  background: #ffffff;
  color: #2fa9b8;
  display: none;
}
.floating-label {
  left: 6%;
}
input:focus {
  color: #2fa9b8 !important;
  outline: none;
  border: 1.5px solid #2fa9b8 !important;
}
textarea:focus {
  color: #2fa9b8 !important;
  outline: none;
  border: 1.5px solid #2fa9b8 !important;
}
select:focus {
  color: #2fa9b8 !important;
  outline: none;
  border: 1.5px solid #2fa9b8 !important;
}

label > input[type="radio"] {
  display: none;
}
label > input[type="checkbox"] {
  display: none;
}
label > input[type="radio"] + *::before {
  content: "";
  display: inline-block;
  vertical-align: bottom;
  width: 1rem;
  height: 1rem;
  margin: 0.3rem;
  border-radius: 50%;
  border-style: solid;
  border-width: 0.1rem;
  border-color: #e8b980;
}
label > input[type="checkbox"] + *::before {
  content: "";
  display: inline-block;
  vertical-align: bottom;
  width: 1rem;
  height: 1rem;
  margin: 0.3rem;
  border-radius: 50%;
  border-style: solid;
  border-width: 0.1rem;
  border-color: #e8b980;
}
label > input[type="radio"]:checked + *::before {
  content: "";
  display: inline-block;
  vertical-align: bottom;
  width: 1rem;
  height: 1rem;
  border-radius: 50%;
  border-style: solid;
  border-width: 0.3rem;
  border-color: #2fa9b8;
}
label > input[type="checkbox"]:checked + *::before {
  content: "";
  display: inline-block;
  vertical-align: bottom;
  width: 1rem;
  height: 1rem;
  border-radius: 50%;
  border-style: solid;
  border-width: 0.3rem;
  border-color: #2fa9b8;
}
label > input[type="radio"]:checked + *::before {
  margin-right: 0.3rem;
}
label > input[type="checkbox"]:checked + *::before {
  margin-right: 0.3rem;
}
label > input[type="radio"]:checked + * {
  color: #2fa9b8;
}
label > input[type="checkbox"]:checked + * {
  color: #2fa9b8;
}
input[type="radio"]:checked:before:before {
  border-color: #2fa9b8;
}

input[type="radio"]:checked ~ .radio-text {
  color: #2fa9b8;
}

input[type="checkbox"]:checked:before:before {
  border-color: #2fa9b8;
}

input[type="checkbox"]:checked ~ .radio-text {
  color: #2fa9b8;
}
.radio-text-r {
  float: right;
}
.radio-text-l {
  float: left;
}

.radio-div {
  padding-top: 2%;
}
.map {
  width: 96%;
  border-radius: 15px;
  height: 15rem;
  margin: 2%;
}
.btn-cancel {
  background-color: #ed1c24;
  border: solid 1px #ed1c24;
  border-radius: 15px;
  width: 96%;
  margin: 2%;
  height: 2.8rem;
  font-style: normal;
  font-weight: 700;
  color: #ffffff;
}
.price {
  background: rgba(20, 250, 0, 0.1);
  border: 2px dashed #000000;
  border-radius: 7px;
  padding-left: 4%;
  padding-right: 4%;
  padding-top: 2%;
}
.div-1 {
  background-color: #ffffff;
  padding: 4%;
  padding-left: 6%;
  padding-right: 6%;
}
.page-subtitle {
  font-style: normal;
  font-weight: 700;
  line-height: 120%;
  color: #ffffff;
  padding-right: 2%;
  padding-left: 2%;
}
.rect {
  position: absolute;
  bottom: 3%;
  left: 0px;
  width: 18%;
}

.div-1 {
  height: auto;
}
.footer-logo {
  width: 10%;
  margin-top: 5%;
  z-index: 1;
}

.btn-cancel {
  font-size: 18px;
  line-height: 27px;
}
.phone-text {
  line-height: 33px;
}
.password-icon {
  width: 30px;
}
.form-button {
  font-size: 18px;
  line-height: 27px;
}
.add-right {
  font-size: 14px;
  line-height: 21px;
}
.add-left {
  font-size: 18px;
  line-height: 27px;
}
.h1,
h1 {
  font-size: 2.5rem !important;
}
.h3,
h3 {
  font-size: 1.5rem !important;
}
.h2,
h2 {
  font-size: 2rem !important;
}

.service_text {
  font-size: 1rem;
}
.phone-text {
  font-size: 1.4rem;
}
.page-title,
.page-subtitle {
  font-size: 2.5rem !important;
}

.social-button {
  width: 5%;
}
.dark-div-text {
  font-size: 1.8rem !important;
}

.footer-sec {
  height: 450px;
}
.foot-dark > p {
  display: block;
}
.home-div {
  height: 600px;
}
.dark-div {
  height: 650px;
}
.phone-text > p {
  display: block;
}
.phone-text > a > img {
  width: 30%;
}
.home-button {
  width: 15%;
  font-weight: 400;
  font-size: 1.5rem;
  line-height: 120%;
  margin-top: 5%;
}
.form-button.home-button {
  width: 15% !important;
}
.back-image {
  width: 100%;
  z-index: -10;
  position: absolute;
  bottom: -3%;
}
.stores {
  margin: 2%;
}
.mobile {
  display: none;
}
.web {
  display: block;
}
.dropdown-menu {
  right: unset !important;
  left: 0 !important;
}
@media only screen and (max-width: 768px) {
  /* For mobile phones: */
  [class*="col-"] {
    width: 100%;
  }
  .web {
    display: none;
  }
  .mobile {
    display: block;
  }
  .footer-sec {
    height: 35vw;
  }
  .div-1 {
    height: auto;
  }
  .home-div {
    height: auto;
  }
  .dark-div {
    height: auto;
  }
  h1 {
    font-size: 1.5rem !important;
    padding-bottom: 22%;
  }
  h2 {
    font-size: 1.25rem !important;
  }
  h3 {
    font-size: 1rem !important;
  }
  .dark-div-text {
    font-size: 1.5rem !important;
  }
  .back-image {
    margin-top: 40%;
  }
  .home-button {
    width: 20%;
    font-size: 1.2rem;
  }
  .phone-text {
    margin-top: 5%;
    margin-left: 0;
    margin-right: 0;
    width: 100%;
    padding: 5%;
  }
  .home-button {
    width: 50%;
    font-size: 1rem;
  }
  .form-box {
    width: 90%;
  }
  .form-box2 {
    width: 90%;
  }
  .add-right {
    text-align: left;
  }
  .btn-cancel {
    width: 95%;
  }
  .stores > img {
    width: 36%;
  }
}
.form-button:focus {
  outline: none;
  box-shadow: none;
}
/* Extra small devices (phones, 600px and down) */
@media only screen and (max-width: 600px) {
  .foot-dark > p {
    display: none;
  }
  .page-title,
  .page-subtitle {
    font-size: 1.5rem !important;
  }
  .foot-dark {
    text-align: center !important;
  }
  .form-button.home-button {
    width: 30% !important;
  }
}

/* Small devices (portrait tablets and large phones, 600px and up) */
@media only screen and (max-width: 992px) {
  .login-btn {
    display: block;
    width: 40% !important;
    margin-top: 2%;
    margin: auto !important;
  }
  .main-page {
    margin-top: 20%;
  }
}

/* Medium devices (landscape tablets, 768px and up) */
@media only screen and (min-width: 768px) {
  h1 {
    font-size: 1.8rem !important;
    padding-bottom: 22%;
  }
  h2 {
    font-size: 1.25rem !important;
  }
  h3 {
    font-size: 1rem !important;
  }
  .dark-div-text {
    font-size: 1.5rem !important;
  }
  .phone-img {
    margin-top: 0;
    margin-left: 0;
    margin-right: 0;
    position: absolute;
    bottom: -30%;
  }
  .footer-sec {
    height: 300px;
  }
}

/* Large devices (laptops/desktops, 992px and up) */
@media only screen and (min-width: 992px) {
  h1 {
    font-size: 2rem !important;
    padding-bottom: 0%;
  }
  h2 {
    font-size: 1.5rem !important;
  }
  h3 {
    font-size: 1.25rem !important;
  }
  .home-button {
    font-size: 1.2rem;
  }
  .phone-img {
    bottom: -40%;
  }
}
@media only screen and (max-width: 992px) {
  .carousel__next > img {
    width: 100%;
  }
  .carousel__prev > img {
    width: 100%;
  }
}
@media only screen and (min-width: 1080px) {
  .phone-img {
    bottom: -50%;
  }
}

/* Extra large devices (large laptops and desktops, 1200px and up) */
@media only screen and (min-width: 1200px) {
  h1 {
    font-size: 2.5rem !important;
    padding-bottom: 0%;
  }
  h2 {
    font-size: 2rem !important;
  }
  h3 {
    font-size: 1.5rem !important;
  }
  .footer-sec {
    height: 450px;
  }
  .phone-img {
    bottom: -70%;
  }
}
body {
  overflow-x: hidden;
}
</style>
