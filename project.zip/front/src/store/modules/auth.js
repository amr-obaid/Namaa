const state = () => ({
  authenticated: false,
  user: {},
  token: "",
});

const getters = {
  isAuthenticated: (state) => state.authenticated,
  userName: (state) => state.user.name,
  token: (state) => state.token,
};

const mutations = {
  SET_USER(state, user) {
    state.user = user;
    state.authenticated = true;
    state.token = user.token;

    // Persist the state in localStorage
    localStorage.setItem("authState", JSON.stringify(state));
  },
  CLEAR_USER(state) {
    state.user = {};
    state.authenticated = false;
    state.token = "";

    // Persist the state in localStorage
    localStorage.setItem("authState", JSON.stringify(state));
  },
  initializeStoreFromLocalStorage(state) {
    // Load state from localStorage
    const storedState = localStorage.getItem("authState");
    if (storedState) {
      const parsedState = JSON.parse(storedState);
      Object.assign(state, parsedState);
    }
  },
};

const actions = {
  async loginUser({ commit }, response) {
    if (response.data.success) {
      commit("SET_USER", response.data.data);
      return true;
    } else {
      console.log(response.data.message);
    }
  },
  logoutUser({ commit }) {
    commit("CLEAR_USER");
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
