<template>
  <div>
    <loading
      :active.sync="isLoading"
      :can-cancel="false"
      :is-full-page="true"
    ></loading>
    <div class="page">
      <div
        class="card"
        v-for="blog in blogs"
        :key="blog.id"
        @click="openModal(blog)"
      >
        <img :src="'http://127.0.0.1:8000' + blog.image" style="width: 100%" />
        <div class="card-container">
          <h4>
            <b>{{ blog.title }}</b>
          </h4>
          <div
            style="
              overflow: hidden;
              text-overflow: ellipsis;
              height: 50px;
              display: -webkit-box;
              -webkit-line-clamp: 2;
              -webkit-box-orient: vertical;
            "
          >
            {{ blog.content }}
          </div>
        </div>
      </div>
    </div>
  </div>
  <Modal v-if="showModal" @click="close">
    <template v-slot:header>
      <h3>{{ selectedBlog.title }}</h3>
    </template>
    <template v-slot:body>
      <div style="width: 80%; margin: auto; padding: 5%">
        <img
          style="width: 50%; display: block; margin: auto"
          :src="'http://127.0.0.1:8000' + selectedBlog.image"
        />
      </div>
      <p>{{ selectedBlog.content }}</p>
    </template>
    <template v-slot:footer> <span></span> </template>
  </Modal>
</template>

<script>
import axios from "axios";
import router from "../router";
import { mapGetters } from "vuex";
import Modal from "../components/Modal.vue";
export default {
  name: "home",
  components: {
    Modal,
  },
  data() {
    return { showModal: false, selectedBlog: {}, blogs: [], isLoading: false };
  },
  computed: {
    ...mapGetters("auth", ["token"]),
  },
  methods: {
    openModal(blog) {
      this.selectedBlog = blog;
      this.showModal = true;
    },
    close() {
      this.showModal = false;
    },
    async getBlogs() {
      await axios
        .get("http://127.0.0.1:8000/api/subscriber/blogs/list", {
          headers: {
            Authorization: "Bearer " + this.token,
          },
        })
        .then((response) => {
          if (!response.data.success) {
            this.error = response.data.message;
          }
          this.blogs = response.data.data;
        })
        .catch((error) => {
          this.error = error.response.data.message;
        });
    },
  },
  beforeMount() {
    this.getBlogs();
  },
};
</script>
<style scoped>
.page {
  padding: 0% 5%;
}
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  transition: 0.3s;
  width: 25%;
  border-radius: 5px;
  cursor: pointer;
  display: inline-block;
  margin: 2%;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
}

.card > img {
  height: 250px;
  border-radius: 5px 5px 0 0;
}

.card-container {
  padding: 2px 16px;
}
</style>