<template>
  <div>
    <loading
      :active.sync="isLoading"
      :can-cancel="false"
      :is-full-page="true"
    ></loading>
    <h3 class="page-title">Login</h3>
    <div class="form-box d-flex align-items-center row">
      <center class="mb-4">
        <img src="../assets/images/logo.png" width="120" />
        <h4>Login to enter our blog</h4>
      </center>
      <div class="form-group">
        <input
          v-model="auth.username"
          class="form-field"
          type="text"
          placeholder="UserName"
        />
        <label class="floating-label">UserName</label>
      </div>
      <div class="form-group">
        <input
          :type="type"
          v-model="auth.password"
          class="form-field"
          placeholder="Password"
        />
        <label class="floating-label">Password</label>
        <font-awesome-icon
          :icon="['fas', 'eye-slash']"
          v-if="!show"
          class="password-icon"
          @click="hidePassword()"
        />
        <font-awesome-icon
          :icon="['fas', 'eye']"
          v-if="show"
          class="password-icon"
          @click="showPassword()"
        />
      </div>

      <span class="danger">{{ error }}</span>
      <input
        type="submit"
        class="form-button col-12 mt-4"
        value="Login"
        @click="login(auth)"
      />
    </div>
    <img
      src="../assets/images/background.png"
      style="width: 100%; position: fixed; bottom: 0; z-index: -100"
    />
  </div>
</template>


<script>
import axios from "axios";
import { mapState, mapActions } from "vuex";
import router from "../router";

export default {
  name: "login",
  methods: {
    hidePassword() {
      this.type = "password";
      this.show = true;
    },
    showPassword() {
      this.type = "text";
      this.show = false;
    },
    ...mapActions("auth", ["loginUser"]),
    login(auth) {
      this.error = "";
      this.isLoading = true;
      try {
        axios
          .post("http://127.0.0.1:8000/api/subscriber/login", auth, {
            headers: {},
          })
          .then((response) => {
            if (!response.data.success) {
              this.error = response.data.message;
            }
            this.loginUser(response);
            router.replace({ path: "/" });
            this.isLoading = false;
          })
          .catch((error) => {
            console.log(error);
            this.error = error.response.data.message;
            this.isLoading = false;
          });
      } catch (error) {
        this.error = error.message;
        this.isLoading = false;
      }
    },
  },
  data() {
    return {
      isLoading: false,
      type: "password",
      show: true,
      error: "",
      auth: {
        username: "",
        password: "",
      },
      rules: {
        required: (value) => !!value || "Required.",
        min: (v) => v.length >= 8 || "Min 8 characters",
        phoneMatch: () => `The phone and password you entered don't match`,
      },
    };
  },
  setup() {
    return {};
  },
};
</script>

<style>
</style>
